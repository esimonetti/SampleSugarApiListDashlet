<?php
$manifest = array (
  'id' => 'SampleSugarApiListDashlet_0.1',
  'built_in_version' => '7.9.0.0',
  'name' => 'SampleSugarApiListDashlet',
  'description' => 'SampleSugarApiListDashlet',
  'version' => '0.1',
  'author' => 'Enrico Simonetti, SugarCRM Inc.',
  'is_uninstallable' => true,
  'published_date' => '2017-07-20 08:13:32',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.9.[\\d]+.[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/custom/Extension/application/Ext/Language/en_us.integration-list-dashlet.php',
      'to' => 'custom/Extension/application/Ext/Language/en_us.integration-list-dashlet.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/custom/modules/Contacts/clients/base/api/IntegrationListApi.php',
      'to' => 'custom/modules/Contacts/clients/base/api/IntegrationListApi.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/custom/modules/Contacts/clients/base/views/integration-list-dashlet/integration-list-dashlet/integration-list-dashlet.hbs',
      'to' => 'custom/modules/Contacts/clients/base/views/integration-list-dashlet/integration-list-dashlet/integration-list-dashlet.hbs',
    ),
    3 => 
    array (
      'from' => '<basepath>/custom/modules/Contacts/clients/base/views/integration-list-dashlet/integration-list-dashlet/integration-list-dashlet.js',
      'to' => 'custom/modules/Contacts/clients/base/views/integration-list-dashlet/integration-list-dashlet/integration-list-dashlet.js',
    ),
    4 => 
    array (
      'from' => '<basepath>/custom/modules/Contacts/clients/base/views/integration-list-dashlet/integration-list-dashlet/integration-list-dashlet.php',
      'to' => 'custom/modules/Contacts/clients/base/views/integration-list-dashlet/integration-list-dashlet/integration-list-dashlet.php',
    ),
  ),
);
